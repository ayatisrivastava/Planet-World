import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';
import HomeScreen from './screens/HomeScreen';
import Details from './screens/Details';

export default function App() {
  return( 
    <AppContainer />
  )
}

const appStackNavigator = createStackNavigator({
  Home: {
    screen: HomeScreen,
    navigationOptions: {
      headerShown: false,
    },
  },
  Details: {
    screen: Details,
  },
},
{
  initialRouteName: "Home"
});

const AppContainer = createAppContainer(appStackNavigator)